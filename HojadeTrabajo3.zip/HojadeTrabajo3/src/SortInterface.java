
/**
 * 
 * @author andreiportales
 *
 */

public interface SortInterface {
	
	
	public void SelectionSort(Integer data[]);
	// pre: 0 <= n <= data.lenght
	// post: values in data[o..n-1] are in ascending order
	
	public void merge(Integer arr[], int l, int m, int r); 
	// pre: data[meddle..high] are ascending , temp[low..middle-1] are ascending
	// post: data[low..high] contains all values in ascending order
	
	public void MergeSort(Integer arr[], int l, int r);
	// pre: data[meddle..high] are ascending , temp[low..middle-1] are ascending
	// post: data[low..high] contains all values in ascending order
	
	public void QuickSort(Integer arr[], int low, int high);
	// post: the values in data[0..,n,1] are in ascending order
	
	
	public int partition(Integer arr[], int low, int high);
	// pre: left <= right
	// post: data[left] placed int he correct (returned) location
	
	
	public int getMax(Integer arr[], int n);
	// pre: n = array size , arr[] array
	// post: return the highest value of the array
	
	public void radixsort(Integer arr[], int n);
	// pre: arr[] array to sort , n = arraySize
	// post: array sorted
	
	public void countSort(Integer arr[], int n, int exp);
	// pre: data is an array of data values, and d >= 0
	// post: data is sorted by the digit found in locationd;
	// if two values have the same digit in location d , their
	// relativa positions do not chande; i.e.; the are not swapped
	 
	public void InsertionSort(Integer arr[]);
	// pre: 0 <= n <= data.length
	// post: values in data[0..n-1] are in ascending order
	
	
	

}
