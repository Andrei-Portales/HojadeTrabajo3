import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.JOptionPane;

/**
 * 
 * @author andreiportales 19825
 *
 */

public class ArchivoTXT {
	
	
	/**
	 * Metodo para guardar lista de enteros en txt
	 * @param numeros: lista de numeros interos
	 */
	 public static void txtWrite(int[] numeros) {
			
			File f = null;
			FileWriter w;
			BufferedWriter bw;
			PrintWriter wr;
			
			
			try {
				f = new File("Datos.txt");
				w = new FileWriter(f);
				bw = new BufferedWriter(w);
				wr = new PrintWriter(bw);
				
				wr.write("");
				
				for (int g:numeros) {
					wr.append(g+",");
				}
				
				wr.close();
				bw.close();
				
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Ha sucedido un error " + e);
			}

		}
	
	
	 
	 /**
	  * Metodo para generar numeros al azar
	  * @param cantidad: cantidad de numeros deseados
	  * @param numeroMaximo: numero al que puede llegar un numero generado
	  * @return
	  */
	public static int[] generarNumeros(int cantidad,int numeroMaximo) {
		int[] array = new int[cantidad];
		for (int i = 0; i < cantidad; i++) {
			array[i] = (int)(Math.random()*numeroMaximo+1);
		}
		return array;
	}
	
	

	/**
	 * Metodo que lee el txt y crea arreglo de los numeros almacenados en el txt
	 * @return: arreglo de enteros 
	 */
	public static Integer[] txtRead() {
		
		File archivo = new File("Datos.txt");
		FileReader fr;
		BufferedReader br;
		
		Integer[] retorno = null;
		try {
			
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);
			
			String leido = "";
			String linea = "";
			
			while((linea = br.readLine()) != null) {
				leido = linea;
			}
			
			String[] split = leido.split(",");
			retorno = new Integer[split.length];
			
		
			for (int i = 0; i< split.length - 1;i++) {
				retorno[i] = Integer.parseInt(split[i]);
			}
			
			
			br.close();
			fr.close();
			
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Ha sucedido un error leyendo el archivo " + e);
		}
		
		return retorno;
	}

}
