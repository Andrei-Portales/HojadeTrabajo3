import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.JOptionPane;

/**
 * 
 * @author andreiportales 19825
 *
 */

public class ArchivoTXT {
	private static String OS = System.getProperty("os.name").toLowerCase();
	
	/**
	 * Metodo para guardar lista de enteros en txt
	 * @param numeros: lista de numeros interos
	 */
	 public static void txtWrite(int[] numeros) {
			
			File f = null;
			FileWriter w;
			BufferedWriter bw;
			PrintWriter wr;
			
			File directorio = null;
			
			if (isWindows()) {
	    		directorio = new File("C:\\Users\\"+ System.getProperty("user.name") +"\\Documents\\DatosHojadeTrabajo_AndreiPortales");
			}else if (isMac()) {
				directorio = new File("/Users/"+ System.getProperty("user.name") +"/Documents/DatosHojadeTrabajo_AndreiPortales");
			}

	    	directorio.mkdir(); 
			
			
			
			try {
				
				if (isWindows()) {
					f = new File("C:\\Users\\"+ System.getProperty("user.name") +"\\Documents\\DatosHojadeTrabajo_AndreiPortales\\Datos.txt");
				}else if (isMac()) {
					f = new File("/Users/"+ System.getProperty("user.name") +"/Documents/DatosHojadeTrabajo_AndreiPortales/Datos.txt");
				}
				
				
				w = new FileWriter(f);
				bw = new BufferedWriter(w);
				wr = new PrintWriter(bw);
				
				wr.write("");
				
				for (int g:numeros) {
					wr.append(g+",");
				}
				
				wr.close();
				bw.close();
				
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Ha sucedido un error " + e);
			}

		}
	
	
	 
	 /**
	  * Metodo para generar numeros al azar
	  * @param cantidad: cantidad de numeros deseados
	  * @param numeroMaximo: numero al que puede llegar un numero generado
	  * @return
	  */
	public static int[] generarNumeros(int cantidad,int numeroMaximo) {
		int[] array = new int[cantidad];
		for (int i = 0; i < cantidad; i++) {
			array[i] = (int)(Math.random()*numeroMaximo+1);
		}
		return array;
	}
	
	
	
	public static String getPath() {
		String path = "";
		if (isWindows()) {
			path = "C:\\Users\\"+ System.getProperty("user.name") +"\\Documents\\DatosHojadeTrabajo_AndreiPortales\\";
		}else if (isMac()) {
			path = "/Users/"+ System.getProperty("user.name") +"/Documents/DatosHojadeTrabajo_AndreiPortales/";
		}
		return path;
	}
	

	/**
	 * Metodo que lee el txt y crea arreglo de los numeros almacenados en el txt
	 * @return: arreglo de enteros 
	 */
	public static Integer[] txtRead() {
		
		File archivo = null;
		
		if (isWindows()) {
			archivo = new File("C:\\Users\\"+ System.getProperty("user.name") +"\\Documents\\DatosHojadeTrabajo_AndreiPortales\\Datos.txt");
		}else if (isMac()) {
			archivo = new File("/Users/"+ System.getProperty("user.name") +"/Documents/DatosHojadeTrabajo_AndreiPortales/Datos.txt");
		}
		
		FileReader fr;
		BufferedReader br;
		
		Integer[] retorno = null;
		try {
			
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);
			
			String leido = "";
			String linea = "";
			
			while((linea = br.readLine()) != null) {
				leido = linea;
			}
			
			String[] split = leido.split(",");
			retorno = new Integer[split.length];
			
		
			for (int i = 0; i< split.length - 1;i++) {
				retorno[i] = Integer.parseInt(split[i]);
			}
			
			
			br.close();
			fr.close();
			
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Ha sucedido un error leyendo el archivo " + e);
		}
		
		return retorno;
	}
	
	
	
	
	
	
	
	
	/**
	 * identifica si el sistema es windows
	 * @return
	 */
	public static boolean isWindows() {
        return (OS.indexOf("win") >= 0);
    }
 
	/**
	 * identifica si el sistema es mac
	 * @return
	 */
    public static boolean isMac() {
        return (OS.indexOf("mac") >= 0);
    }
	
	
	
	

}
