import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

public class PruebasJUNIT {

	private Integer[] datos = new Integer[] {5,4,3,2,6,5,4,3,7,6,5,8,7,4,6,3,4,1,9,0,7,5,4,3,1,6,8,4,5,6};
	private Integer[] esperado = new Integer[] {0,1,1,2,3,3,3,3,4,4,4,4,4,4,5,5,5,5,5,6,6,6,6,6,7,7,7,8,8,9};
	private Sort sort = new Sort();
	
	
	@Test
	public void testSelectionSort() {
		Integer[] temp = datos.clone();
		sort.SelectionSort(temp);
		assertArrayEquals(esperado, temp);
	}
	
	@Test
	public void testMergeSort() {
		Integer[] temp = datos.clone();
		sort.MergeSort(temp, 0, 29);
		assertArrayEquals(esperado, temp);
	}
	
	@Test
	public void testQuickSort() {
		Integer[] temp = datos.clone();
		sort.QuickSort(temp, 0, 29);
		assertArrayEquals(esperado, temp);
	}
	
	@Test
	public void testRadixSort() {
		Integer[] temp = datos.clone();
		sort.radixsort(temp, 30);
		assertArrayEquals(esperado, temp);
	}
	
	@Test
	public void testInsertionSort() {
		Integer[] temp = datos.clone();
		sort.InsertionSort(temp);
		assertArrayEquals(esperado, temp);
	}

}
