import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import net.miginfocom.swing.MigLayout;
import java.awt.Color;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;

import org.jfree.chart.ChartPanel;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.border.BevelBorder;

public class Main {

	private JFrame frame;
	private Controller control;
	private JPanel graficaDesordenados,graficaOrdenados;
	private JButton btnSimular;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main window = new Main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		control = new Controller();
		frame = new JFrame();
		frame.setBounds(100, 100, 1396, 802);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new CardLayout(0, 0));
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		frame.getContentPane().add(panel, "name_36578303865612");
		panel.setLayout(null);
		
		
		graficaDesordenados = new JPanel();
		graficaDesordenados.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		graficaDesordenados.setBackground(Color.WHITE);
		graficaDesordenados.setBounds(458, 17, 921, 365);
		panel.add(graficaDesordenados);
		graficaDesordenados.setLayout(new GridLayout(1, 0, 0, 0));
		
		
		
		//graficaDesordenados.validate();
		//graficaDesordenados.removeAll();
		//graficaDesordenados.add(Graficas.getGrafica(new double[] {16877.0, 101869.0, 379824.0, 4565446.0, 4382454.0, 1329026.0, 2424912.0, 1732873.0, 2287466.0, 2612861.0, 3567254.0, 4190596.0, 4788647.0}, "Datos"));
		
		//panel_1.validate();
		//panel_1.removeAll();
		//panel_1.add(control.getGrafica());
		
		graficaOrdenados = new JPanel();
		graficaOrdenados.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		graficaOrdenados.setBackground(Color.WHITE);
		graficaOrdenados.setBounds(458, 409, 921, 365);
		panel.add(graficaOrdenados);
		graficaOrdenados.setLayout(new GridLayout(1, 0, 0, 0));
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.BLACK);
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(440, 6, 12, 768);
		panel.add(separator);
		
		JLabel lblNewLabel = new JLabel("Simulador de Sorts");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 20));
		lblNewLabel.setBounds(110, 6, 193, 56);
		panel.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Generar Numeros");
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 30));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String a = control.generarNumeros(3000,3000);
					JOptionPane.showMessageDialog(null, "Se generaron 3000 numeros y se guardaron en " + a);
				}catch(Exception e0) {
					JOptionPane.showMessageDialog(null, "Error al generar los numeros, intente de nuevo");
				}
			}
		});
		btnNewButton.setBounds(20, 95, 384, 81);
		panel.add(btnNewButton);
		
		btnSimular = new JButton("Simular Sorts");
		btnSimular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				control.Simulacion();
				ChartPanel[] graficas =  control.getGraficas();
				
				
				graficaDesordenados.validate();
				graficaDesordenados.removeAll();
				graficaDesordenados.add(graficas[0]);
				graficaDesordenados.updateUI();
				
				graficaOrdenados.validate();
				graficaOrdenados.removeAll();
				graficaOrdenados.add(graficas[1]);
				graficaOrdenados.updateUI();
			}
		});
		btnSimular.setFont(new Font("Arial", Font.PLAIN, 30));
		btnSimular.setBounds(20, 200, 384, 81);
		panel.add(btnSimular);
		
		JButton btnCrearImagenesDe = new JButton("Crear Imagenes de Graficas");
		btnCrearImagenesDe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String p = control.getImageGraficas();
					JOptionPane.showMessageDialog(null, "Se guardaron las imagenes en " + p);
				}catch (Exception ex) {
					JOptionPane.showMessageDialog(null,"Error al generar las imagenes");
				}
				
			}
		});
		btnCrearImagenesDe.setFont(new Font("Arial", Font.PLAIN, 25));
		btnCrearImagenesDe.setBounds(20, 409, 384, 81);
		panel.add(btnCrearImagenesDe);
		
		
	}
}
