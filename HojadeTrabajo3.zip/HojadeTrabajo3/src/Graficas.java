import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.DefaultXYDataset;

public class Graficas {

	/**
	 * Metodo para generar graficas
	 * @param datosY
	 * @param Titulo
	 * @return
	 */
	public static ChartPanel getGrafica(double[][] datosY,String Titulo) {
		
		DefaultXYDataset dataset = new DefaultXYDataset();
		
		double[] datX = new double[] {10,50,100,500,1000,1200,1600,1800,2000,2200,2600,2800,2999};
		
		//{16877.0, 101869.0, 379824.0, 4565446.0, 4382454.0, 1329026.0, 2424912.0, 1732873.0, 2287466.0, 2612861.0, 3567254.0, 4190596.0, 4788647.0}
		
        dataset.addSeries("Selection Sort", new double[][] {datX, datosY[0]});
        dataset.addSeries("Merge Sort", new double[][] {datX, datosY[1]});
        dataset.addSeries("Quick Sort", new double[][] {datX, datosY[2]});
        dataset.addSeries("Radix Sort", new double[][] {datX, datosY[3]});
        dataset.addSeries("Insertion Sort", new double[][] {datX, datosY[4]});

        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
        renderer.setSeriesPaint(0, Color.ORANGE);
        renderer.setSeriesPaint(1, Color.BLUE);
        renderer.setSeriesPaint(2, Color.GREEN);
        renderer.setSeriesPaint(3, Color.RED);
        renderer.setSeriesPaint(4, Color.MAGENTA);
        
        renderer.setSeriesStroke(0, new BasicStroke(2));
        renderer.setSeriesStroke(1, new BasicStroke(2));
        renderer.setSeriesStroke(2, new BasicStroke(2));
        renderer.setSeriesStroke(3, new BasicStroke(2));
        renderer.setSeriesStroke(4, new BasicStroke(2));

        JFreeChart chart = ChartFactory.createXYLineChart(Titulo, "Datos Ordenados", "Tiempo (Nanosegundos)", dataset);
        //chart.getXYPlot().getRangeAxis().setRange(0, 100);
        //((NumberAxis) chart.getXYPlot().getRangeAxis()).setNumberFormatOverride(new DecimalFormat("#'%'"));
        chart.getXYPlot().setRenderer(renderer);

        ChartPanel graph = new ChartPanel(chart);
        return graph;
	}
	
	
	/**
	 * Metodo para crear las imagenes de las graficas 
	 * @param datosY
	 * @param Titulo
	 * @param path
	 */
	public static void getImgGrafica(double[][] datosY,String Titulo,String path) {
		
		DefaultXYDataset dataset = new DefaultXYDataset();
		
		double[] datX = new double[] {10,50,100,500,1000,1200,1600,1800,2000,2200,2600,2800,2999};
		
		//{16877.0, 101869.0, 379824.0, 4565446.0, 4382454.0, 1329026.0, 2424912.0, 1732873.0, 2287466.0, 2612861.0, 3567254.0, 4190596.0, 4788647.0}
		
        dataset.addSeries("Selection Sort", new double[][] {datX, datosY[0]});
        dataset.addSeries("Merge Sort", new double[][] {datX, datosY[1]});
        dataset.addSeries("Quick Sort", new double[][] {datX, datosY[2]});
        dataset.addSeries("Radix Sort", new double[][] {datX, datosY[3]});
        dataset.addSeries("Insertion Sort", new double[][] {datX, datosY[4]});

        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
        renderer.setSeriesPaint(0, Color.ORANGE);
        renderer.setSeriesPaint(1, Color.BLUE);
        renderer.setSeriesPaint(2, Color.GREEN);
        renderer.setSeriesPaint(3, Color.RED);
        renderer.setSeriesPaint(4, Color.MAGENTA);
        
        renderer.setSeriesStroke(0, new BasicStroke(2));
        renderer.setSeriesStroke(1, new BasicStroke(2));
        renderer.setSeriesStroke(2, new BasicStroke(2));
        renderer.setSeriesStroke(3, new BasicStroke(2));
        renderer.setSeriesStroke(4, new BasicStroke(2));

        JFreeChart chart = ChartFactory.createXYLineChart(Titulo, "Datos Ordenados", "Tiempo (Nanosegundos)", dataset);
        //chart.getXYPlot().getRangeAxis().setRange(0, 100);
        //((NumberAxis) chart.getXYPlot().getRangeAxis()).setNumberFormatOverride(new DecimalFormat("#'%'"));
        chart.getXYPlot().setRenderer(renderer);

        BufferedImage image = chart.createBufferedImage(600, 400);
        
        try {
			ImageIO.write(image, "png", new File(path + Titulo + ".png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
       
	}
	
	
	
	
}
