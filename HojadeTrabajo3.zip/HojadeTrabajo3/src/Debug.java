

public class Debug {
	
	public static void main(String[] args) {
		
		
		
		
		
		
	}

}
