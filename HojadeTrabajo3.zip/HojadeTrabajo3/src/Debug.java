

public class Debug {
	
	public static void main(String[] args) {
		
		//{10,50,100,500,1000,1200,1600,1800,2000,2200,2600,2800,3000}
		
		Controller c = new Controller();
		Sort sort = new Sort();
		
		c.generarNumeros(3000, 30000);
		
		c.leerTxt();
		
		Integer[] data = c.getTXT();
		
		Integer[] tempdata = new Integer[10];
		
		for (int i = 0 ;i<= 9;i++) {
			tempdata[i] = data[i];
		}
		
		sort.SelectionSort(tempdata);
		
		//sort.SelectionSort(tempdata);
		
	}

}
