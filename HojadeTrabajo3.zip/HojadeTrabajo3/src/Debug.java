import java.util.Arrays;

public class Debug {
	
	public static void main(String[] args) {
		Sort sort = new Sort();
		
		Integer[] dat = new Integer[] {3,4,6,5,1,2,8,7,5,3,4,6,2,3,0};
		
		Integer[] dat2 = dat.clone();
		
		System.out.println(Arrays.toString(dat));
		System.out.println(Arrays.toString(dat2));
		
		sort.SelectionSort(dat2);
		System.out.println();
		
		
		System.out.println(Arrays.toString(dat));
		System.out.println(Arrays.toString(dat2));
		
		
	}

}
