import java.io.File;
import java.util.Arrays;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


import org.jfree.chart.ChartPanel;


public class Controller {

	private Sort sort;
	private Integer[] datos;
	private double[][] tiemposDesordenados;
	private double[][] tiemposOrdenados;
	private ChartPanel graficaDesordenados;
	private ChartPanel graficaOrdenados;
	
	
	public Controller() {
		graficaDesordenados = null;
		graficaOrdenados = null;
		sort = new Sort();
		datos = null;
		tiemposDesordenados = new double[5][13];
		tiemposOrdenados = new double[5][13];
	}
	
	/**
	 * Metodo para crear las imagenes de las graficas
	 * @return: path de archivos
	 */
	public String getImageGraficas() {
		Graficas.getImgGrafica(tiemposDesordenados, "Listas Desordenados",ArchivoTXT.getPath());
		Graficas.getImgGrafica(tiemposOrdenados, "Listas Ordenados",ArchivoTXT.getPath());
		
		return ArchivoTXT.getPath();
	}
	
	
	/**
	 * MEtodo para obtener las tablas de datos
	 * @return: lista de tablas
	 */
	public JTable[] getTablas(){
		JTable[] tablas = new JTable[2];
		
		DefaultTableModel model1 = new DefaultTableModel();
		DefaultTableModel model2 = new DefaultTableModel();
		
		//10	50	100	500	1000	1200	1600	1800	2000	2200	2600	2800	3000
		
		
		model1.setColumnCount(14);
		model1.setRowCount(5);
		model1.setColumnIdentifiers(new String[] {"Datos Ordenados","10","50","100","500","1000","1200","1600","1800","2000","2200","2600","2800","3000"});
		
		
		model2.setColumnCount(14);
		model2.setRowCount(5);
		model2.setColumnIdentifiers(new String[] {"Datos Ordenados","10","50","100","500","1000","1200","1600","1800","2000","2200","2600","2800","3000"});
		
		String[] selections = new String[] {"Selection Sort","Merge Sort","Quick Sort","Radix Sort","Insertion Sort"};
		
		
		for (int i = 0 ; i<= 4;i++) {
			model1.setValueAt(selections[i], i, 0);
			model1.setValueAt(tiemposDesordenados[i][0], i, 1);
			model1.setValueAt(tiemposDesordenados[i][1], i, 2);
			model1.setValueAt(tiemposDesordenados[i][2], i, 3);
			model1.setValueAt(tiemposDesordenados[i][3], i, 4);
			model1.setValueAt(tiemposDesordenados[i][4], i, 5);
			model1.setValueAt(tiemposDesordenados[i][5], i, 6);
			model1.setValueAt(tiemposDesordenados[i][6], i, 7);
			model1.setValueAt(tiemposDesordenados[i][7], i, 8);
			model1.setValueAt(tiemposDesordenados[i][8], i, 9);
			model1.setValueAt(tiemposDesordenados[i][9], i, 10);
			model1.setValueAt(tiemposDesordenados[i][10], i, 11);
			model1.setValueAt(tiemposDesordenados[i][11], i, 12);
			model1.setValueAt(tiemposDesordenados[i][12], i, 13);
			
		}
		
		for (int i = 0 ; i<= 4;i++) {
			model2.setValueAt(selections[i], i, 0);
			model2.setValueAt(tiemposOrdenados[i][0], i, 1);
			model2.setValueAt(tiemposOrdenados[i][1], i, 2);
			model2.setValueAt(tiemposOrdenados[i][2], i, 3);
			model2.setValueAt(tiemposOrdenados[i][3], i, 4);
			model2.setValueAt(tiemposOrdenados[i][4], i, 5);
			model2.setValueAt(tiemposOrdenados[i][5], i, 6);
			model2.setValueAt(tiemposOrdenados[i][6], i, 7);
			model2.setValueAt(tiemposOrdenados[i][7], i, 8);
			model2.setValueAt(tiemposOrdenados[i][8], i, 9);
			model2.setValueAt(tiemposOrdenados[i][9], i, 10);
			model2.setValueAt(tiemposOrdenados[i][10], i, 11);
			model2.setValueAt(tiemposOrdenados[i][11], i, 12);
			model2.setValueAt(tiemposOrdenados[i][12], i, 13);
		}
		
		tablas[0] = new JTable(model1);
		tablas[1] = new JTable(model2);
		
		return tablas;
	}
	
	
	
	/**
	 * Metodo que devuelve una lista de las graficas generadas
	 * @return: lista de graficas
	 */
	public ChartPanel[] getGraficas() {

		graficaDesordenados = Graficas.getGrafica(tiemposDesordenados, "Listas Desordenados");
		graficaOrdenados = Graficas.getGrafica(tiemposOrdenados, "Listas Ordenadas");
		
		return (new ChartPanel[] {graficaDesordenados,graficaOrdenados});
	}
	
	
	/**
	 * Metodo para generar numeros al azar y guardarlos en txt
	 * @param cantidad: cantidad de numeros
	 * @param numMaximo: cantidad maximo de numero generado
	 */
	public String generarNumeros(int cantidad,int numMaximo) {
		ArchivoTXT.txtWrite(ArchivoTXT.generarNumeros(cantidad, numMaximo));
		return ArchivoTXT.getPath();
	}
	
	/**
	 * Metodo para leer el txt 
	 */
	public void leerTxt() {
		datos = ArchivoTXT.txtRead();
		
	}
	
	public Integer[] getTXT() {
		return datos;
	}
	
	/**
	 * Metodo para realizar la simulacion
	 */
	public void Simulacion() {
		leerTxt();
		simularSelectionSort();
		simularMergeSort();
		simularQuickSort();
		simularRadixSort();
		simularInsertionSort();
		
	}
	
	
	
	/**
	 * Metodo para simulat selection sort
	 */
	public void simularSelectionSort() {
		
		Integer[] cantidades= new Integer[] {10,50,100,500,1000,1200,1600,1800,2000,2200,2600,2800,2999};
		
		for (int i = 0; i<=cantidades.length -1;i++) {
			Integer[] tempDataTotal = datos.clone();
			long tiempoInicio = 0;
			long tiempoFinal = 0;
			
			
			Integer[] tempDat = new Integer[cantidades[i]];
			
			
			
			for (int o = 0; o <= cantidades[i] -1;o++) {
				tempDat[o] = tempDataTotal[o];
			}
			
			
			
			//System.out.println(Arrays.toString(tempDat));
			tiempoInicio = System.nanoTime();
			sort.SelectionSort(tempDat);
			tiempoFinal = System.nanoTime();
			tiemposDesordenados[0][i] = Math.abs(tiempoInicio - tiempoFinal); 
			
			
			tiempoInicio = System.nanoTime();
			sort.SelectionSort(tempDat);
			tiempoFinal = System.nanoTime();
			tiemposOrdenados[0][i] = Math.abs(tiempoInicio - tiempoFinal); 
			
		}
		
	}
	
	
	
	/**
	 * Metodo para simular merge sort
	 */
	public void simularMergeSort() {
		Integer[] cantidades= new Integer[] {10,50,100,500,1000,1200,1600,1800,2000,2200,2600,2800,2999};
		
		for (int i = 0; i<=12;i++) {
			Integer[] tempDataTotal = datos.clone();
			long tiempoInicio = 0;
			long tiempoFinal = 0;
			
			Integer[] tempDat = new Integer[cantidades[i]];
			for (int o = 0; o < cantidades[i];o++) {
				tempDat[o] = tempDataTotal[o];
			}
			
			tiempoInicio = System.nanoTime();
			sort.MergeSort(tempDat, 0, cantidades[i]-1);
			tiempoFinal = System.nanoTime();
			tiemposDesordenados[1][i] = Math.abs(tiempoInicio - tiempoFinal);
			
			
			tiempoInicio = System.nanoTime();
			sort.MergeSort(tempDat, 0, cantidades[i]-1);
			tiempoFinal = System.nanoTime();
			tiemposOrdenados[1][i] = Math.abs(tiempoInicio - tiempoFinal); 
			
		}
	}
	
	
	
	/**
	 * Metodo para simular quick sort
	 */
	public void simularQuickSort() {
		Integer[] cantidades= new Integer[] {10,50,100,500,1000,1200,1600,1800,2000,2200,2600,2800,2999};
		
		for (int i = 0; i<=12;i++) {
			Integer[] tempDataTotal = datos.clone();
			long tiempoInicio = 0;
			long tiempoFinal = 0;
			
			Integer[] tempDat = new Integer[cantidades[i]];
			for (int o = 0; o < cantidades[i];o++) {
				tempDat[o] = tempDataTotal[o];
			}
			
			tiempoInicio = System.nanoTime();
			sort.QuickSort(tempDat, 0, cantidades[i] - 1);
			tiempoFinal = System.nanoTime();
			tiemposDesordenados[2][i] = Math.abs(tiempoInicio - tiempoFinal);
			
			
			tiempoInicio = System.nanoTime();
			sort.QuickSort(tempDat, 0, cantidades[i] - 1);
			tiempoFinal = System.nanoTime();
			tiemposOrdenados[2][i] = Math.abs(tiempoInicio - tiempoFinal);
			
		}
		
	}
	
	
	/**
	 * Metodo para simular el Radix sort
	 */
	public void simularRadixSort() {
		Integer[] cantidades= new Integer[] {10,50,100,500,1000,1200,1600,1800,2000,2200,2600,2800,2999};
		
		for (int i = 0; i<=12;i++) {
			Integer[] tempDataTotal = datos.clone();
			long tiempoInicio = 0;
			long tiempoFinal = 0;
			
			Integer[] tempDat = new Integer[cantidades[i]];
			for (int o = 0; o < cantidades[i];o++) {
				tempDat[o] = tempDataTotal[o];
			}
		
			tiempoInicio = System.nanoTime();
			sort.radixsort(tempDat, cantidades[i]);
			tiempoFinal = System.nanoTime();
			tiemposDesordenados[3][i] = Math.abs(tiempoInicio - tiempoFinal);
			
			
			tiempoInicio = System.nanoTime();
			sort.radixsort(tempDat, cantidades[i]);
			tiempoFinal = System.nanoTime();
			tiemposOrdenados[3][i] = Math.abs(tiempoInicio - tiempoFinal);
			
			
			
		}
			
	}
	
	
	/**
	 * Metodo para simular Insertion sort
	 */
	public void simularInsertionSort() {
		
		Integer[] cantidades= new Integer[] {10,50,100,500,1000,1200,1600,1800,2000,2200,2600,2800,2999};
		
		for (int i = 0; i<=12;i++) {
			long tiempoInicio = 0;
			long tiempoFinal = 0;
			Integer[] tempDataTotal = datos.clone();
			Integer[] tempDat = new Integer[cantidades[i]];
			
			for (int o = 0; o < cantidades[i];o++) {
				
				tempDat[o] = tempDataTotal[o];
			}
			
			tiempoInicio = System.nanoTime();
			sort.InsertionSort(tempDat);
			tiempoFinal = System.nanoTime();
			tiemposDesordenados[4][i] = Math.abs(tiempoInicio - tiempoFinal);
			
			
			tiempoInicio = System.nanoTime();
			sort.InsertionSort(tempDat);
			tiempoFinal = System.nanoTime();
			tiemposOrdenados[4][i] = Math.abs(tiempoInicio - tiempoFinal);
			
			
		}

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
