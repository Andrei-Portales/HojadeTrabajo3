import java.io.File;
import java.util.Arrays;

import org.jfree.chart.ChartPanel;

public class Controller {

	private Sort sort;
	private Integer[] datos;
	private double[][] tiemposDesordenados;
	private double[][] tiemposOrdenados;
	private ChartPanel graficaDesordenados;
	private ChartPanel graficaOrdenados;
	
	
	public Controller() {
		graficaDesordenados = null;
		graficaOrdenados = null;
		sort = new Sort();
		datos = null;
		tiemposDesordenados = new double[5][13];
		tiemposOrdenados = new double[5][13];
	}
	
	
	public String getImageGraficas() {
		Graficas.getImgGrafica(tiemposDesordenados, "Listas Desordenados",ArchivoTXT.getPath());
		Graficas.getImgGrafica(tiemposOrdenados, "Listas Ordenados",ArchivoTXT.getPath());
		
		return ArchivoTXT.getPath();
	}
	
	
	public ChartPanel[] getGraficas() {

		graficaDesordenados = Graficas.getGrafica(tiemposDesordenados, "Listas Desordenados");
		graficaOrdenados = Graficas.getGrafica(tiemposOrdenados, "Listas Ordenadas");
		
		return (new ChartPanel[] {graficaDesordenados,graficaOrdenados});
	}
	
	
	/**
	 * Metodo para generar numeros al azar y guardarlos en txt
	 * @param cantidad: cantidad de numeros
	 * @param numMaximo: cantidad maximo de numero generado
	 */
	public String generarNumeros(int cantidad,int numMaximo) {
		ArchivoTXT.txtWrite(ArchivoTXT.generarNumeros(cantidad, numMaximo));
		return ArchivoTXT.getPath();
	}
	
	/**
	 * Metodo para leer el txt 
	 */
	public void leerTxt() {
		datos = ArchivoTXT.txtRead();
		
	}
	
	public Integer[] getTXT() {
		return datos;
	}
	
	/**
	 * Metodo para realizar la simulacion
	 */
	public void Simulacion() {
		leerTxt();
		simularSelectionSort();
		simularMergeSort();
		simularQuickSort();
		simularRadixSort();
		simularInsertionSort();
		
	}
	
	
	
	/**
	 * Metodo para simulat selection sort
	 */
	public void simularSelectionSort() {
		
		Integer[] cantidades= new Integer[] {10,50,100,500,1000,1200,1600,1800,2000,2200,2600,2800,2999};
		
		for (int i = 0; i<=cantidades.length -1;i++) {
			Integer[] tempDataTotal = datos.clone();
			long tiempoInicio = 0;
			long tiempoFinal = 0;
			
			
			Integer[] tempDat = new Integer[cantidades[i]];
			
			
			
			for (int o = 0; o <= cantidades[i] -1;o++) {
				tempDat[o] = tempDataTotal[o];
			}
			
			
			
			//System.out.println(Arrays.toString(tempDat));
			tiempoInicio = System.nanoTime();
			sort.SelectionSort(tempDat);
			tiempoFinal = System.nanoTime();
			tiemposDesordenados[0][i] = Math.abs(tiempoInicio - tiempoFinal); 
			
			
			tiempoInicio = System.nanoTime();
			sort.SelectionSort(tempDat);
			tiempoFinal = System.nanoTime();
			tiemposOrdenados[0][i] = Math.abs(tiempoInicio - tiempoFinal); 
			
		}
		
	}
	
	
	
	/**
	 * Metodo para simular merge sort
	 */
	public void simularMergeSort() {
		Integer[] cantidades= new Integer[] {10,50,100,500,1000,1200,1600,1800,2000,2200,2600,2800,2999};
		
		for (int i = 0; i<=12;i++) {
			Integer[] tempDataTotal = datos.clone();
			long tiempoInicio = 0;
			long tiempoFinal = 0;
			
			Integer[] tempDat = new Integer[cantidades[i]];
			for (int o = 0; o < cantidades[i];o++) {
				tempDat[o] = tempDataTotal[o];
			}
			
			tiempoInicio = System.nanoTime();
			sort.MergeSort(tempDat, 0, cantidades[i]-1);
			tiempoFinal = System.nanoTime();
			tiemposDesordenados[1][i] = Math.abs(tiempoInicio - tiempoFinal);
			
			
			tiempoInicio = System.nanoTime();
			sort.MergeSort(tempDat, 0, cantidades[i]-1);
			tiempoFinal = System.nanoTime();
			tiemposOrdenados[1][i] = Math.abs(tiempoInicio - tiempoFinal); 
			
		}
	}
	
	
	
	/**
	 * Metodo para simular quick sort
	 */
	public void simularQuickSort() {
		Integer[] cantidades= new Integer[] {10,50,100,500,1000,1200,1600,1800,2000,2200,2600,2800,2999};
		
		for (int i = 0; i<=12;i++) {
			Integer[] tempDataTotal = datos.clone();
			long tiempoInicio = 0;
			long tiempoFinal = 0;
			
			Integer[] tempDat = new Integer[cantidades[i]];
			for (int o = 0; o < cantidades[i];o++) {
				tempDat[o] = tempDataTotal[o];
			}
			
			tiempoInicio = System.nanoTime();
			sort.QuickSort(tempDat, 0, cantidades[i] - 1);
			tiempoFinal = System.nanoTime();
			tiemposDesordenados[2][i] = Math.abs(tiempoInicio - tiempoFinal);
			
			
			tiempoInicio = System.nanoTime();
			sort.QuickSort(tempDat, 0, cantidades[i] - 1);
			tiempoFinal = System.nanoTime();
			tiemposOrdenados[2][i] = Math.abs(tiempoInicio - tiempoFinal);
			
		}
		
	}
	
	
	
	public void simularRadixSort() {
		Integer[] cantidades= new Integer[] {10,50,100,500,1000,1200,1600,1800,2000,2200,2600,2800,2999};
		
		for (int i = 0; i<=12;i++) {
			Integer[] tempDataTotal = datos.clone();
			long tiempoInicio = 0;
			long tiempoFinal = 0;
			
			Integer[] tempDat = new Integer[cantidades[i]];
			for (int o = 0; o < cantidades[i];o++) {
				tempDat[o] = tempDataTotal[o];
			}
		
			tiempoInicio = System.nanoTime();
			sort.radixsort(tempDat, cantidades[i]);
			tiempoFinal = System.nanoTime();
			tiemposDesordenados[3][i] = Math.abs(tiempoInicio - tiempoFinal);
			
			
			tiempoInicio = System.nanoTime();
			sort.radixsort(tempDat, cantidades[i]);
			tiempoFinal = System.nanoTime();
			tiemposOrdenados[3][i] = Math.abs(tiempoInicio - tiempoFinal);
			
			
			
		}
			
	}
	
	
	
	public void simularInsertionSort() {
		
		Integer[] cantidades= new Integer[] {10,50,100,500,1000,1200,1600,1800,2000,2200,2600,2800,2999};
		
		for (int i = 0; i<=12;i++) {
			long tiempoInicio = 0;
			long tiempoFinal = 0;
			Integer[] tempDataTotal = datos.clone();
			Integer[] tempDat = new Integer[cantidades[i]];
			
			for (int o = 0; o < cantidades[i];o++) {
				
				tempDat[o] = tempDataTotal[o];
			}
			
			tiempoInicio = System.nanoTime();
			sort.InsertionSort(tempDat);
			tiempoFinal = System.nanoTime();
			tiemposDesordenados[4][i] = Math.abs(tiempoInicio - tiempoFinal);
			System.out.println( Math.abs(tiempoInicio - tiempoFinal));
			
			tiempoInicio = System.nanoTime();
			sort.InsertionSort(tempDat);
			tiempoFinal = System.nanoTime();
			tiemposOrdenados[4][i] = Math.abs(tiempoInicio - tiempoFinal);
			System.out.println( Math.abs(tiempoInicio - tiempoFinal));
			
		}

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
