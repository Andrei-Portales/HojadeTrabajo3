import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.text.DecimalFormat;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.DefaultXYDataset;

public class Controller {

	private Sort sort;
	private Integer[] datos;
	private double[][] tiemposDesordenados;
	private double[][] tiemposOrdenados;
	
	
	public Controller() {
		sort = new Sort();
		datos = null;
		tiemposDesordenados = new double[5][13];
		tiemposOrdenados = new double[5][13];
	}
	
	
	/**
	 * Metodo para generar numeros al azar y guardarlos en txt
	 * @param cantidad: cantidad de numeros
	 * @param numMaximo: cantidad maximo de numero generado
	 */
	public void generarNumeros(int cantidad,int numMaximo) {
		ArchivoTXT.txtWrite(ArchivoTXT.generarNumeros(cantidad, numMaximo));
	}
	
	
	public void leerTxt() {
		datos = ArchivoTXT.txtRead();
	}
	
	
	public void Simulacion() {
		simularSelectionSort();
		simularMergeSort();
		
	}
	
	
	
	
	private void simularSelectionSort() {
		Integer[] cantidades= new Integer[] {10,50,100,500,1000,1200,1600,1800,2000,2200,2600,1800,3000};
		
		for (int i = 0; i<=12;i++) {
			long tiempoInicio = 0;
			long tiempoFinal = 0;
			
			Integer[] tempDat = new Integer[cantidades[i]];
			
			for (int o = 0; o < cantidades[i];o++) {
				tempDat[o] = datos[o];
			}
			
			tiempoInicio = System.nanoTime();
			sort.SelectionSort(tempDat);
			tiempoFinal = System.nanoTime();
			tiemposDesordenados[0][i] = Math.abs(tiempoInicio - tiempoFinal); 
			
			tiempoInicio = System.nanoTime();
			sort.SelectionSort(tempDat);
			tiempoFinal = System.nanoTime();
			tiemposOrdenados[0][i] = Math.abs(tiempoInicio - tiempoFinal); 
		}
		
	}
	
	
	private void simularMergeSort() {
		Integer[] cantidades= new Integer[] {10,50,100,500,1000,1200,1600,1800,2000,2200,2600,1800,3000};
		
		for (int i = 0; i<=12;i++) {
			long tiempoInicio = 0;
			long tiempoFinal = 0;
			
			Integer[] tempDat = new Integer[cantidades[i]];
			for (int o = 0; o < cantidades[i];o++) {
				tempDat[o] = datos[o];
			}
			
			tiempoInicio = System.nanoTime();
			sort.MergeSort(tempDat, 0, cantidades[i]-1);
			tiempoFinal = System.nanoTime();
			tiemposDesordenados[1][i] = Math.abs(tiempoInicio - tiempoFinal);
			
			tiempoInicio = System.nanoTime();
			sort.MergeSort(tempDat, 0, cantidades[i]-1);
			tiempoFinal = System.nanoTime();
			tiemposOrdenados[1][i] = Math.abs(tiempoInicio - tiempoFinal); 
		}
	}
	
	
	
	
	
	
	public void generarNumeros(int cantidad) {
		Integer[] array = new Integer[] {2,5,7,4,2,9,8,6,4,1};
		long tiempoInicio = System.nanoTime();
		//s.SelectionSort(array);
		long timepoFinal = System.nanoTime();
		System.out.println(tiempoInicio);
		System.out.println(timepoFinal);
		long tiempoTotal = Math.abs(tiempoInicio - timepoFinal);
		System.out.println("El ordenamiento se tardo: "+ tiempoTotal +" Nanosegundos");
	}
	
	
	
	
	public ChartPanel getGrafica(double[][] datosY,String Titulo) {
		
		DefaultXYDataset dataset = new DefaultXYDataset();
		
		double[] datX = new double[] {10,50,100,500,1000,1200,1600,1800,2000,2200,2600,1800,3000};
		
		
        dataset.addSeries("Selection Sort", new double[][] {datX, datosY[0]});
        dataset.addSeries("Merge Sort", new double[][] {datX, datosY[1]});
        dataset.addSeries("Quick Sort", new double[][] {datX, datosY[2]});
        dataset.addSeries("Radix Sort", new double[][] {datX, datosY[3]});
        dataset.addSeries("Insertion Sort", new double[][] {datX, datosY[4]});

        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
        renderer.setSeriesPaint(0, Color.ORANGE);
        renderer.setSeriesPaint(1, Color.BLUE);
        renderer.setSeriesPaint(2, Color.GREEN);
        renderer.setSeriesPaint(3, Color.RED);
        renderer.setSeriesPaint(4, Color.MAGENTA);
        
        renderer.setSeriesStroke(0, new BasicStroke(2));
        renderer.setSeriesStroke(1, new BasicStroke(2));
        renderer.setSeriesStroke(2, new BasicStroke(2));
        renderer.setSeriesStroke(3, new BasicStroke(2));
        renderer.setSeriesStroke(4, new BasicStroke(2));

        JFreeChart chart = ChartFactory.createXYLineChart(Titulo, "Datos Ordenados", "Tiempo (Nanosegundos)", dataset);
        //chart.getXYPlot().getRangeAxis().setRange(0, 100);
        //((NumberAxis) chart.getXYPlot().getRangeAxis()).setNumberFormatOverride(new DecimalFormat("#'%'"));
        //chart.getXYPlot().setRenderer(renderer);

        ChartPanel graph = new ChartPanel(chart);
        return graph;
	}
	
	
	
	
	
}
